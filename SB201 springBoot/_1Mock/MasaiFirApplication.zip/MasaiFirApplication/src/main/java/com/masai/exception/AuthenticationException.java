package com.masai.exception;

public class AuthenticationException extends RuntimeException{

	public AuthenticationException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AuthenticationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
	

}
