package com.masai.exception;

public class FirException extends RuntimeException{

	public FirException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FirException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
